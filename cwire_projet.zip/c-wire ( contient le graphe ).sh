#!/bin/bash

###############################################################################
# c-wire.sh
# Script Shell principal en FRANÇAIS pour le projet c-wire.
#
# Utilisation :
#   ./c-wire.sh <fichier_csv> <type_station> <type_consommateur> [options]
#
# Paramètres obligatoires :
#   1) chemin du fichier CSV (ex : input/data_cwire.csv)
#   2) type de station : hvb | hva | lv
#   3) type de consommateur : comp (entreprises) | indiv (particuliers) | all (tous)
#
# Options possibles :
#   -c <identifiant_centrale> : ne traite qu’une seule centrale
#   -h : affiche l’aide et quitte
#
# Exemples :
#   ./c-wire.sh input/data_cwire.csv hvb comp
#   ./c-wire.sh input/data_cwire.csv lv all -c 12
###############################################################################

FICHIER_CSV="$1"
TYPE_STATION="$2"
TYPE_CONSOMMATEUR="$3"

shift 3

ID_CENTRALE=""

while (( "$#" )); do
  case "$1" in
    -c)
      ID_CENTRALE="$2"
      shift 2
      ;;
    -h)
      echo "===================================================================="
      echo "Aide du script c-wire.sh"
      echo "Usage: $0 <fichier_csv> <type_station> <type_consommateur> [options]"
      echo "       type_station : hvb | hva | lv"
      echo "       type_consommateur : comp | indiv | all"
      echo
      echo "Options disponibles :"
      echo "  -c <id_centrale> : filtrer sur l’identifiant d’une centrale"
      echo "  -h               : afficher l’aide et quitter"
      echo "===================================================================="
      exit 0
      ;;
    *)
      echo "[ERREUR] Option inconnue : $1"
      exit 1
      ;;
  esac
done

# Vérifications de base
if [ -z "$FICHIER_CSV" ] || [ -z "$TYPE_STATION" ] || [ -z "$TYPE_CONSOMMATEUR" ]; then
  echo "[ERREUR] Paramètres manquants. Revoir la syntaxe."
  exit 1
fi

# Vérifier si l’exécutable C existe déjà, sinon on compile via Makefile
EXEC="./code/c-wire"

if [ ! -f "$EXEC" ]; then
  echo "[INFO] L’exécutable c-wire n’est pas trouvé. Je lance la compilation..."
  (cd code && make)
  if [ ! -f "$EXEC" ]; then
    echo "[ERREUR] Échec de la compilation. On abandonne."
    exit 1
  fi
fi

# On prépare un dossier temporaire
if [ -d "tmp" ]; then
  rm -f tmp/*
else
  mkdir tmp
fi

FICHIER_FILTRE="tmp/filtre.csv"

# Filtrer selon le type de station
case "$TYPE_STATION" in
  hvb)
    grep -i "Station HV-B" "$FICHIER_CSV" > "$FICHIER_FILTRE"
    ;;
  hva)
    grep -i "Station HV-A" "$FICHIER_CSV" > "$FICHIER_FILTRE"
    ;;
  lv)
    grep -i "Station LV" "$FICHIER_CSV" > "$FICHIER_FILTRE"
    ;;
  *)
    echo "[ERREUR] Type de station inconnu : $TYPE_STATION"
    exit 1
    ;;
esac

# Filtrer selon le type de consommateur (entreprises, particuliers, tous)
if [ "$TYPE_CONSOMMATEUR" = "comp" ]; then
  grep -i "company" "$FICHIER_FILTRE" > tmp/tmp2.csv
  mv tmp/tmp2.csv "$FICHIER_FILTRE"
elif [ "$TYPE_CONSOMMATEUR" = "indiv" ]; then
  grep -i "individual" "$FICHIER_FILTRE" > tmp/tmp2.csv
  mv tmp/tmp2.csv "$FICHIER_FILTRE"
elif [ "$TYPE_CONSOMMATEUR" = "all" ]; then
  # on ne fait rien, on garde tout
  :
else
  echo "[ERREUR] Type de consommateur inconnu : $TYPE_CONSOMMATEUR"
  exit 1
fi

# Si on a spécifié une centrale, on filtre encore
if [ -n "$ID_CENTRALE" ]; then
  grep -i "$ID_CENTRALE" "$FICHIER_FILTRE" > tmp/tmp3.csv
  mv tmp/tmp3.csv "$FICHIER_FILTRE"
fi

# Nom du fichier de sortie
FICHIER_SORTIE="tests/${TYPE_STATION}_${TYPE_CONSOMMATEUR}.csv"
if [ -n "$ID_CENTRALE" ]; then
  FICHIER_SORTIE="tests/${TYPE_STATION}_${TYPE_CONSOMMATEUR}_${ID_CENTRALE}.csv"
fi

# On exécute le programme C en lui passant les données filtrées
"$EXEC" < "$FICHIER_FILTRE" > "$FICHIER_SORTIE"

# Bonus : si on est en "lv all", on fait le fameux min/max
if [ "$TYPE_STATION" = "lv" ] && [ "$TYPE_CONSOMMATEUR" = "all" ]; then
  FICHIER_MINMAX="tests/lv_all_minmax.csv"

  # On suppose que FICHIER_SORTIE contient déjà : identifiant_station:capacite:consommation
  awk -F ":" '{
     diff = $2 - $3
     print $0 ":" diff
  }' "$FICHIER_SORTIE" > tmp/lv_temp.csv

  # On trie par la différence (colonne 4) en ordre croissant
  sort -t ":" -k4n tmp/lv_temp.csv > tmp/lv_temp_trie.csv

  echo "Noeuds extrêmes selon (capacité - consommation)" > "$FICHIER_MINMAX"

  echo "=== 10 plus petits écarts ===" >> "$FICHIER_MINMAX"
  head -n 10 tmp/lv_temp_trie.csv >> "$FICHIER_MINMAX"

  echo "" >> "$FICHIER_MINMAX"
  echo "=== 10 plus gros écarts ===" >> "$FICHIER_MINMAX"
  tail -n 10 tmp/lv_temp_trie.csv >> "$FICHIER_MINMAX"
fi

echo "[OK] Traitement terminé avec succès. Les résultats se trouvent dans le dossier tests/."

exit 0
