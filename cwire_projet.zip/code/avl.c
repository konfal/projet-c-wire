#include <stdio.h>
#include <stdlib.h>
#include "avl.h"

// Petite fonction utilitaire pour le max
static int maxEntier(int a, int b) {
    return (a > b) ? a : b;
}

// Pour récupérer la hauteur d’un noeud (ou 0 si NULL)
static int hauteur(NoeudAVL* n) {
    return (n == NULL) ? 0 : n->hauteur;
}

// Créer un nouveau noeud
static NoeudAVL* creer_noeud(long id_station, long capacite, long conso) {
    NoeudAVL* noeud = malloc(sizeof(NoeudAVL));
    noeud->identifiant_station = id_station;
    noeud->capacite = capacite;
    noeud->somme_consommation = conso;
    noeud->hauteur = 1;
    noeud->gauche = NULL;
    noeud->droite = NULL;
    return noeud;
}

// Rotations à droite
static NoeudAVL* rotation_droite(NoeudAVL* y) {
    NoeudAVL* x = y->gauche;
    NoeudAVL* T2 = x->droite;

    // Rotation
    x->droite = y;
    y->gauche = T2;

    // Mise à jour des hauteurs
    y->hauteur = maxEntier(hauteur(y->gauche), hauteur(y->droite)) + 1;
    x->hauteur = maxEntier(hauteur(x->gauche), hauteur(x->droite)) + 1;

    return x; // x devient la racine du sous-arbre
}

// Rotations à gauche
static NoeudAVL* rotation_gauche(NoeudAVL* x) {
    NoeudAVL* y = x->droite;
    NoeudAVL* T2 = y->gauche;

    // Rotation
    y->gauche = x;
    x->droite = T2;

    // Mise à jour des hauteurs
    x->hauteur = maxEntier(hauteur(x->gauche), hauteur(x->droite)) + 1;
    y->hauteur = maxEntier(hauteur(y->gauche), hauteur(y->droite)) + 1;

    return y; // y devient la racine du sous-arbre
}

// Calcul de l'équilibre
static int equilibrage(NoeudAVL* n) {
    if (!n) return 0;
    return hauteur(n->gauche) - hauteur(n->droite);
}

// Insertion dans l'AVL
NoeudAVL* avl_inserer(NoeudAVL* racine, long id_station, long capacite, long conso) {
    // 1) Insertion BST classique
    if (racine == NULL) {
        return creer_noeud(id_station, capacite, conso);
    }

    if (id_station < racine->identifiant_station) {
        racine->gauche = avl_inserer(racine->gauche, id_station, capacite, conso);
    }
    else if (id_station > racine->identifiant_station) {
        racine->droite = avl_inserer(racine->droite, id_station, capacite, conso);
    }
    else {
        // Même station => on met à jour la consommation
        racine->somme_consommation += conso;
        // Pour la capacité, on prend la plus grande
        if (capacite > racine->capacite) {
            racine->capacite = capacite;
        }
        return racine;
    }

    // 2) Mettre à jour la hauteur du noeud
    racine->hauteur = 1 + maxEntier(hauteur(racine->gauche), hauteur(racine->droite));

    // 3) Vérifier l'équilibre
    int balance = equilibrage(racine);

    // Cas 1 : Gauche-Gauche
    if (balance > 1 && id_station < racine->gauche->identifiant_station) {
        return rotation_droite(racine);
    }

    // Cas 2 : Droite-Droite
    if (balance < -1 && id_station > racine->droite->identifiant_station) {
        return rotation_gauche(racine);
    }

    // Cas 3 : Gauche-Droite
    if (balance > 1 && id_station > racine->gauche->identifiant_station) {
        racine->gauche = rotation_gauche(racine->gauche);
        return rotation_droite(racine);
    }

    // Cas 4 : Droite-Gauche
    if (balance < -1 && id_station < racine->droite->identifiant_station) {
        racine->droite = rotation_droite(racine->droite);
        return rotation_gauche(racine);
    }

    return racine;
}

// Parcours inorder (trié selon l’identifiant de station). 
// On l’utilise surtout pour déboguer si besoin.
void avl_inorder(NoeudAVL* racine) {
    if (!racine) return;
    avl_inorder(racine->gauche);
    printf("ID=%ld, Capacité=%ld, SommeConso=%ld\n",
        racine->identifiant_station,
        racine->capacite,
        racine->somme_consommation);
    avl_inorder(racine->droite);
}

// Libère toute la mémoire de l'arbre
void avl_libere(NoeudAVL* racine) {
    if (!racine) return;
    avl_libere(racine->gauche);
    avl_libere(racine->droite);
    free(racine);
}
