#ifndef AVL_H
#define AVL_H

// Un noeud de notre arbre AVL enti�rement en fran�ais
typedef struct NoeudAVL {
    long identifiant_station;  // identifiant unique
    long capacite;             // capacit� en kWh
    long somme_consommation;   // somme des consommations
    int hauteur;               // hauteur du noeud dans l'arbre
    struct NoeudAVL* gauche;
    struct NoeudAVL* droite;
} NoeudAVL;

// Fonctions qu'on va utiliser
NoeudAVL* avl_inserer(NoeudAVL* racine, long id_station, long capacite, long conso);
void      avl_inorder(NoeudAVL* racine);
void      avl_libere(NoeudAVL* racine);

#endif
