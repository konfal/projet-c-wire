#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"

/*
   c-wire.c (VERSION FRAN�AISE)
   ============================
   - On lit les lignes filtr�es par le script Shell sur stdin,
   - Chaque ligne devrait ressembler � :
       identifiant_station:capacite:consommation
   - On ins�re tout �a dans un arbre AVL,
   - Puis, � la fin, on veut un tri final par "capacite",
     donc on copie les noeuds dans un tableau et on fait un qsort.
   - Enfin, on affiche les r�sultats sur stdout.
*/

#define NB_STATIONS_MAX 3000000 // Ajuste selon tes besoins m�moire

static NoeudAVL* tableauNoeuds[NB_STATIONS_MAX];
static int compteur = 0;

// On fait un parcours inorder pour tout stocker dans tableauNoeuds
// (puis on pourra trier sur la capacit�)
void remplirTableauInorder(NoeudAVL* racine) {
    if (!racine) return;
    remplirTableauInorder(racine->gauche);
    tableauNoeuds[compteur++] = racine;
    remplirTableauInorder(racine->droite);
}

// Comparateur pour trier sur la capacite
int comparerCapacite(const void* a, const void* b) {
    const NoeudAVL* na = *(const NoeudAVL**)a;
    const NoeudAVL* nb = *(const NoeudAVL**)b;
    if (na->capacite < nb->capacite) return -1;
    if (na->capacite > nb->capacite) return  1;
    return 0;
}

int main(void) {
    NoeudAVL* racine = NULL;
    char ligne[1024];

    // Si la premi�re ligne est un en-t�te, on peut la zapper :
    // fgets(ligne, sizeof(ligne), stdin);

    while (fgets(ligne, sizeof(ligne), stdin)) {
        // On enl�ve le \n si pr�sent
        char* pos = strchr(ligne, '\n');
        if (pos) *pos = '\0';

        // On s�attend � "identifiant_station:capacite:consommation"
        long id_station = 0;
        long capacite = 0;
        long conso = 0;

        char* token = strtok(ligne, ":");
        if (!token) continue;
        id_station = atol(token);

        token = strtok(NULL, ":");
        if (!token) continue;
        capacite = atol(token);

        token = strtok(NULL, ":");
        if (!token) continue;
        conso = atol(token);

        // On ins�re dans l'AVL
        racine = avl_inserer(racine, id_station, capacite, conso);
    }

    // Maintenant, on veut trier par capacite,
    // donc on remplit un tableau via un parcours inorder
    compteur = 0;
    remplirTableauInorder(racine);

    // On fait le qsort sur la capacite
    qsort(tableauNoeuds, compteur, sizeof(NoeudAVL*), comparerCapacite);

    // On envoie �a sur la sortie standard au format "id_station:capacite:conso"
    for (int i = 0; i < compteur; i++) {
        printf("%ld:%ld:%ld\n",
            tableauNoeuds[i]->identifiant_station,
            tableauNoeuds[i]->capacite,
            tableauNoeuds[i]->somme_consommation);
    }

    // On lib�re l'arbre ()
    avl_libere(racine);

    return 0;
}
